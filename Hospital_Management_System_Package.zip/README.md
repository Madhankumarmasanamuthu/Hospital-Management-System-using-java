# Hospital Management System (Console, Java + MySQL)

A simple console-based Hospital Management System that manages Patients, Doctors, and Appointments.

## Features
- Add a patient
- View all patients
- View all doctors
- Book an appointment (auto-prevents double booking per doctor per day)

## Requirements
- Java JDK 8+ (tested on JDK 17)
- MySQL Server 8.x (or compatible)
- MySQL Connector/J 8.x (JDBC driver)

## 1) Database Setup (MySQL)

Open MySQL client or Workbench and run the SQL script in this repo:

```
SOURCE /absolute/path/to/hospital_schema.sql;
```

Or copy-paste the contents of `hospital_schema.sql` and execute.

This will:
- Create database `hospital`
- Create tables: `doctors`, `patients`, `appointments`
- Add sample doctor/patient rows
- Add a unique constraint `uq_doctor_date` to prevent double-booking the same doctor on the same date

## 2) Configure DB Credentials

Open `src/HospitalManagementSystem/HospitalManagementSystem.java` and update:

```java
private static final String url = "jdbc:mysql://localhost:3306/hospital";
private static final String username = "root";
private static final String password = "Admin@123"; // <-- change to your MySQL password
```

> Tip: If you use XAMPP/MAMP/WAMP, update host/port/user/pass accordingly. For MAMP on macOS the default port is 8889: `jdbc:mysql://localhost:8889/hospital`.

## 3) Add MySQL JDBC Driver

**Option A — IntelliJ (recommended)**  
- Open the project folder in IntelliJ IDEA.
- File → Project Structure → Libraries → `+` → From Maven: search `mysql:mysql-connector-j:8.1.0` → Add.
- Or download the MySQL Connector/J jar and add it as a Library.

**Option B — CLI compile & run**
Download the Connector/J jar (e.g., `mysql-connector-j-8.1.0.jar`) and put it somewhere, then:

**Windows (PowerShell):**
```powershell
javac -cp ".;C:\path\to\mysql-connector-j-8.1.0.jar" src/HospitalManagementSystem/*.java
java  -cp ".;C:\path\to\mysql-connector-j-8.1.0.jar;src" HospitalManagementSystem.HospitalManagementSystem
```

**macOS/Linux (bash):**
```bash
javac -cp ".:/path/to/mysql-connector-j-8.1.0.jar" src/HospitalManagementSystem/*.java
java  -cp ".:/path/to/mysql-connector-j-8.1.0.jar:src" HospitalManagementSystem.HospitalManagementSystem
```

## 4) Run

When you run the app, you should see:

```
HOSPITAL MANAGEMENT SYSTEM 
1. Add Patient
2. View Patients
3. View Doctors
4. Book Appointment
5. Exit
Enter your choice:
```

**Book Appointment flow**
- You’ll be prompted for `patientId`, `doctorId`, and `appointment_date` in `YYYY-MM-DD` format.
- The system checks the doctor’s availability (no double booking for the same date).

## 5) Common Fixes

- **Communications link failure / Access denied** → Confirm URL/username/password. Ensure MySQL is started.
- **`com.mysql.cj.jdbc.Driver` not found** → You didn’t add Connector/J to the classpath.
- **`Table 'hospital.doctors' doesn't exist`** → You didn’t run `hospital_schema.sql` (Step 1).

## 6) File Map

```
src/
  HospitalManagementSystem/
    Doctor.java
    Patient.java
    HospitalManagementSystem.java
hospital_schema.sql
```

## 7) Notes
- Names and genders are read with `Scanner.next()`; avoid spaces or adjust to use `nextLine()` if you prefer multi-word input.
- The sample code uses simple console menus for clarity.