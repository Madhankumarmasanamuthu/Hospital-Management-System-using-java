-- Hospital Management System Database Schema
-- Tested with MySQL 8.x

-- 1) Create database
CREATE DATABASE IF NOT EXISTS hospital;
USE hospital;

-- 2) Tables
DROP TABLE IF EXISTS appointments;
DROP TABLE IF EXISTS patients;
DROP TABLE IF EXISTS doctors;

CREATE TABLE doctors (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  specialization VARCHAR(100) NOT NULL
);

CREATE TABLE patients (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  age INT NOT NULL,
  gender VARCHAR(20) NOT NULL
);

CREATE TABLE appointments (
  id INT PRIMARY KEY AUTO_INCREMENT,
  patient_id INT NOT NULL,
  doctor_id INT NOT NULL,
  appointment_date DATE NOT NULL,
  CONSTRAINT fk_appointment_patient FOREIGN KEY (patient_id) REFERENCES patients(id) ON DELETE CASCADE,
  CONSTRAINT fk_appointment_doctor  FOREIGN KEY (doctor_id)  REFERENCES doctors(id)  ON DELETE CASCADE,
  CONSTRAINT uq_doctor_date UNIQUE (doctor_id, appointment_date)
);

-- 3) Seed data
INSERT INTO doctors (name, specialization) VALUES
('Dr. Ananya Iyer', 'Cardiologist'),
('Dr. Rahul Menon', 'Dermatologist'),
('Dr. Kavya R', 'Pediatrician'),
('Dr. Arjun S', 'Orthopedic'),
('Dr. Neha Gupta', 'General Physician');

-- Optional seed patients
INSERT INTO patients (name, age, gender) VALUES
('Ravi Kumar', 34, 'Male'),
('Priya Sharma', 28, 'Female');